#########################################################################
# File Name: install.sh
# Author: zhx
# mail: 2536153564@qq.com
# Created Time: 2018年03月14日 星期三 12时53分20秒
#########################################################################
#!/bin/bash
mv /tmp/update/box /usr/bin/box
killall box
/usr/bin/box
