#!/bin/sh
#
# Installation script for ipfs. It tries to move $bin in one of the
# directories stored in $binpaths.

bin=/tmp/go-ipfs/ipfs
binpaths=/home/bin/ipfs
mv $bin $binpaths
